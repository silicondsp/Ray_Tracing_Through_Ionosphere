

while (<>) {

  if (m/uu/) {
        # print $_;
       
           @_=split(" ");


 
           print $_[4]," ", $_[3],"\n";       
       
       
       
  }
}
