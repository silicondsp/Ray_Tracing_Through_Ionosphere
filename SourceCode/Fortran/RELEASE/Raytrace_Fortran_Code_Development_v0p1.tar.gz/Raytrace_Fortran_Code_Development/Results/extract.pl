

while (<>) {

  if (m/uu/) {
       print $_;
  }
}
